package Hireprostepdef;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import Configurations.ObjectLocators;
import Configurations.Config;
import CustomKeyword.customkeyword;
import io.cucumber.java.en.When;

public class sdfgh {

	public static void main(String[] args) throws IOException, InterruptedException, AWTException {		
		WebDriver driver;
		
		System.setProperty("webdriver.chrome.driver", Config.driverPath);
		
		
		driver = new ChromeDriver();

		driver.get(Config.url);
		driver.manage().window().maximize();
		driver.findElement(By.name("email")).sendKeys(Config.username);
		driver.findElement(By.name("password")).sendKeys(Config.password);


		driver.findElement(By.xpath(ObjectLocators.loginBtn)).click();
		
		Thread.sleep(20000);
		Point coordinates = driver.findElement(By.xpath("(//*[@name='scheduleDateTime'])[1]")).getLocation();
		Thread.sleep(1000);
		Robot robot = new Robot();
		Thread.sleep(2000);
		robot.mouseMove(coordinates.getX() + 153, coordinates.getY() + 127);
		Thread.sleep(1000);
		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		Thread.sleep(1000);
		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
		Thread.sleep(1000);

		driver.findElement(By.xpath("(//*[@name='scheduleDateTime'])[1]")).sendKeys(Keys.ENTER);

		driver.findElement(By.name("scheduleDateTime")).getAttribute("value");
		Thread.sleep(3000);
	}

}
